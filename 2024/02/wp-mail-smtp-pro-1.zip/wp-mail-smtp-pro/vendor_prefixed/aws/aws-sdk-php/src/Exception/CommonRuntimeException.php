<?php

namespace WPMailSMTP\Vendor\Aws\Exception;

class CommonRuntimeException extends \RuntimeException
{
}
