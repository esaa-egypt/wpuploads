<?php
namespace OrganizeSeries\domain\interfaces;

interface AjaxRequestInterface
{
}