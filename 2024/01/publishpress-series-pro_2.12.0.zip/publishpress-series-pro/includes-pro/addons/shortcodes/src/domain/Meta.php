<?php
namespace OrganizeSeries\ShortcodesAddon\domain;

use OrganizeSeries\domain\interfaces\AbstractMeta;

class Meta extends AbstractMeta
{
    //Used for any shortcodes add-on specific paths etc.
}