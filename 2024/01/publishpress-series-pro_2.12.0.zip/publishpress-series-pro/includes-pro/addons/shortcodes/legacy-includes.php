<?php
//let's include required files
require_once OS_SHORTCODE_PATH . 'os-shortcodes-main.php';

//load up plugin main stuff
$os_shortcodes = new os_Shortcodes();
