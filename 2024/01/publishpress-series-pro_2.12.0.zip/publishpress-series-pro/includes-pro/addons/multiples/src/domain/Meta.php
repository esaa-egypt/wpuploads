<?php

namespace OrganizeSeries\MultiplesAddon\domain;

use OrganizeSeries\domain\interfaces\AbstractMeta;

class Meta extends AbstractMeta
{
    //Used for any multiples specific paths etc.
}